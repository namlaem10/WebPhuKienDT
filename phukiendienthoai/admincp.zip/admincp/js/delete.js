// JavaScript Document
$('.delete_link').on('click',function(){
	var thongbao='Bạn chắc chắn xóa ??';
	return confirm(thongbao);
    
});
	
	
	
	
