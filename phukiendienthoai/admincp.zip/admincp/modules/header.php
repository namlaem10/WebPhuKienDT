<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"><head>
<link rel="stylesheet" type="text/css" href="style/css.css" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
</head>
<div class="header">
    	<h3>Welcome to admincp</h3>
    </div>
<style>
.header{
	width:100%;
	height:120px;
	text-align:center;
	line-height:120px;
	font-size:40px;
	color:#000;	
}
</style>