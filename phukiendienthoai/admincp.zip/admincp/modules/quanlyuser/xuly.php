<?php
	include('../config.php');
	$fullname=$_POST['fullname'];
	$email=$_POST['email'];
	$phonenumber=$_POST['phonenumber'];
	$address=$_POST['address'];
	$username=$_POST['username'];
	$password=$_POST['password'];
	if(isset($_POST['them'])){
		//them
		 $sql_them=("insert into user (fullname,email,phonenumber,address,username,password) value($fullname,$email,$phonenumber,$address,$username,$password)");
		mysqli_query($con,$sql_them);
		header('location:../../index.php?quanly=user&ac=lietke');
	}elseif(isset($_POST['sua'])){
		//sua
	  $sql_sua = "update user set fullname='$fullname',email='$email',phonenumber='$phonenumber',address='$address',username='$username' where iduser='$_GET[id]'";
		mysqli_query($con,$sql_sua);
		header('location:../../index.php?quanly=user&ac=lietke');
	}else{
		$sql_xoa = "delete from user where iduser = $_GET[id]";
		mysqli_query($con,$sql_xoa);
		header('location:../../index.php?quanly=user&ac=lietke');
	}
?>
